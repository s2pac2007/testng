package Domilexus;

public class TestBase {

}
